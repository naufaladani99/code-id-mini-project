"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/404";
exports.ids = ["pages/404"];
exports.modules = {

/***/ "./pages/404.js":
/*!**********************!*\
  !*** ./pages/404.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Custom404)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction Custom404() {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();\n    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{\n        setTimeout(()=>{\n            router.push(\"/\");\n        }, 2000);\n    });\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"main\", {\n            class: \"h-screen w-full flex flex-col justify-center items-center bg-[#1A2238]\",\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h1\", {\n                    class: \"text-9xl font-extrabold text-white tracking-widest\",\n                    children: \"404\"\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\woles\\\\Desktop\\\\benew\\\\MiniProject_client_batch18-Naufal-bootcamp\\\\pages\\\\404.js\",\n                    lineNumber: 14,\n                    columnNumber: 17\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    class: \"bg-[#FF6A3D] px-2 text-sm rounded rotate-12 absolute\",\n                    children: \"Page Not Found\"\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\woles\\\\Desktop\\\\benew\\\\MiniProject_client_batch18-Naufal-bootcamp\\\\pages\\\\404.js\",\n                    lineNumber: 15,\n                    columnNumber: 17\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                    class: \"mt-5\",\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"a\", {\n                        class: \"relative inline-block text-sm font-medium text-[#FF6A3D] group active:text-orange-500 focus:outline-none focus:ring\",\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                            class: \"absolute inset-0 transition-transform translate-x-0.5 translate-y-0.5 bg-[#FF6A3D] group-hover:translate-y-0 group-hover:translate-x-0\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\woles\\\\Desktop\\\\benew\\\\MiniProject_client_batch18-Naufal-bootcamp\\\\pages\\\\404.js\",\n                            lineNumber: 22,\n                            columnNumber: 25\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\woles\\\\Desktop\\\\benew\\\\MiniProject_client_batch18-Naufal-bootcamp\\\\pages\\\\404.js\",\n                        lineNumber: 19,\n                        columnNumber: 21\n                    }, this)\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\woles\\\\Desktop\\\\benew\\\\MiniProject_client_batch18-Naufal-bootcamp\\\\pages\\\\404.js\",\n                    lineNumber: 18,\n                    columnNumber: 17\n                }, this)\n            ]\n        }, void 0, true, {\n            fileName: \"C:\\\\Users\\\\woles\\\\Desktop\\\\benew\\\\MiniProject_client_batch18-Naufal-bootcamp\\\\pages\\\\404.js\",\n            lineNumber: 13,\n            columnNumber: 13\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\woles\\\\Desktop\\\\benew\\\\MiniProject_client_batch18-Naufal-bootcamp\\\\pages\\\\404.js\",\n        lineNumber: 12,\n        columnNumber: 9\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy80MDQuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBO0FBQXVDO0FBQ0M7QUFFekIsU0FBU0csWUFBWTtJQUNoQyxNQUFNQyxTQUFTSixzREFBU0E7SUFDeEJFLGdEQUFTQSxDQUFDLElBQU07UUFDWkcsV0FBVyxJQUFNO1lBQ2JELE9BQU9FLElBQUksQ0FBQztRQUNoQixHQUFHO0lBQ1A7SUFDQSxxQkFDSSw4REFBQ0M7a0JBQ0csNEVBQUNDO1lBQUtDLE9BQU07OzhCQUNSLDhEQUFDQztvQkFBR0QsT0FBTTs4QkFBcUQ7Ozs7Ozs4QkFDL0QsOERBQUNGO29CQUFJRSxPQUFNOzhCQUF1RDs7Ozs7OzhCQUdsRSw4REFBQ0U7b0JBQU9GLE9BQU07OEJBQ1YsNEVBQUNHO3dCQUNHSCxPQUFNO2tDQUVOLDRFQUFDSTs0QkFDR0osT0FBTTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBT2xDLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9mZS10ZW1wbGF0ZS8uL3BhZ2VzLzQwNC5qcz8zZWQ5Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ25leHQvcm91dGVyJ1xuaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDdXN0b200MDQoKSB7XG4gICAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKClcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgIHJvdXRlci5wdXNoKCcvJylcbiAgICAgICAgfSwgMjAwMClcbiAgICB9KVxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bWFpbiBjbGFzcz1cImgtc2NyZWVuIHctZnVsbCBmbGV4IGZsZXgtY29sIGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBiZy1bIzFBMjIzOF1cIj5cbiAgICAgICAgICAgICAgICA8aDEgY2xhc3M9XCJ0ZXh0LTl4bCBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIHRyYWNraW5nLXdpZGVzdFwiPjQwNDwvaDE+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImJnLVsjRkY2QTNEXSBweC0yIHRleHQtc20gcm91bmRlZCByb3RhdGUtMTIgYWJzb2x1dGVcIj5cbiAgICAgICAgICAgICAgICAgICAgUGFnZSBOb3QgRm91bmRcbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwibXQtNVwiPlxuICAgICAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJyZWxhdGl2ZSBpbmxpbmUtYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LVsjRkY2QTNEXSBncm91cCBhY3RpdmU6dGV4dC1vcmFuZ2UtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImFic29sdXRlIGluc2V0LTAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gdHJhbnNsYXRlLXgtMC41IHRyYW5zbGF0ZS15LTAuNSBiZy1bI0ZGNkEzRF0gZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXktMCBncm91cC1ob3Zlcjp0cmFuc2xhdGUteC0wXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvbWFpbj5cbiAgICAgICAgPC9kaXY+XG4gICAgKVxufVxuIl0sIm5hbWVzIjpbInVzZVJvdXRlciIsIlJlYWN0IiwidXNlRWZmZWN0IiwiQ3VzdG9tNDA0Iiwicm91dGVyIiwic2V0VGltZW91dCIsInB1c2giLCJkaXYiLCJtYWluIiwiY2xhc3MiLCJoMSIsImJ1dHRvbiIsImEiLCJzcGFuIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/404.js\n");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/404.js"));
module.exports = __webpack_exports__;

})();