import LandingPage from "../component/layout/LandingPage";

export default function hiring() {
  return (
    <div>
      <LandingPage>
        Hiring
      </LandingPage>
    </div>
  )
}
