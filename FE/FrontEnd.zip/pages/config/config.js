module.exports = {
    domain: 'http://localhost:3003',
}