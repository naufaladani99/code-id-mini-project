import React from 'react'
import AppLayout from '../../component/layout/AppLayout';

export default function Talent() {
  return (
    <AppLayout>
      <div>Talent</div>
    </AppLayout>
  )
}
