import React from 'react'

import AppLayout from '../../component/layout/AppLayout';
export default function Candidat() {
  return (
    <AppLayout>
      <div>Candidat</div>
    </AppLayout>
  )
}
