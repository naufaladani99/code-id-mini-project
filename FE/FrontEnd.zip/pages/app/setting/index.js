import React from 'react'
import AppLayout from '../../component/layout/AppLayout';

export default function Setting() {
  return (
    <AppLayout>
      <div>Setting</div>
    </AppLayout>
  )
}
