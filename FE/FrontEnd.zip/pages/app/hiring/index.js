import React from "react";

import AppLayout from "../../component/layout/AppLayout";

export default function Hiring() {
  return (
    <AppLayout>
      <div>Hiring</div>
    </AppLayout>
  );
}
