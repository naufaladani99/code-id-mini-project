import React from 'react'

import AppLayout from '../../component/layout/AppLayout';
export default function Curriculum() {
  return (
    <AppLayout>
      <div>Curriculum</div>
    </AppLayout>
  )
}
