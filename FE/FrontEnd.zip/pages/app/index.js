import React from 'react'
import AppLayout from '../component/layout/AppLayout'

export default function Dashboard() {
    return (
        <div>
            <AppLayout>
                index
            </AppLayout>
        </div>
    )
}
