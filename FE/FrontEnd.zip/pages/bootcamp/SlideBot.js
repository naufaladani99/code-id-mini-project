import React from "react";
import Kartus from "./Kartus";

function SlideBot() {
  return (
    <div className=" border shadow my-6 bg-gray-200 p-[150px] h-[500px] rounded-lg w-[90%] ml-[5%]">
      {/* border shadow my-6 */}
      {/* <h1 className="text-xl mt-[2px] mb-[2px]">Testimonial</h1> */}
      {/* <div className="border-4 border-black w-2/5 mx-auto h-4/5 h-auto"> */}
      <div>
        <Kartus />
      </div>
    </div>
  );
}

export default SlideBot;
