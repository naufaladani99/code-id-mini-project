//tabel program_entity
export const GET_BOOTCAMP_REQUEST = "get/bootcamp/request";
export const GET_BOOTCAMP_SUCCES = "get/bootcamp/success";
export const GET_BOOTCAMP_FAILED = "get/bootcamp/failed";

//tabel program_entity getby id
export const GET_ID_BOOTCAMP_REQUEST = "get/get_id_bootcamp/request";
export const GET_ID_BOOTCAMP_SUCCES = "get/get_id_bootcamp/success";
export const GET_ID_BOOTCAMP_FAILED = "get/get_id_bootcamp/failed";

//tabel review
export const GET_REVIEW_REQUEST = "get/review/request";
export const GET_REVIEW_SUCCES = "get/review/success";
export const GET_REVIEW_FAILED = "get/review/failed";
