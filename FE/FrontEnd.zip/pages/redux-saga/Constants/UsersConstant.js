export const GET_ALL_USERS_REQUEST = "get/get_all_users/request";
export const GET_ALL_USERS_SUCCES = "get/get_all_users/success";
export const GET_ALL_USERS_FAILED = "get/get_all_users/failed";

export const GET_ID_USERS_REQUEST = "get/get_id_users/request";
export const GET_ID_USERS_SUCCES = "get/get_id_users/success";
export const GET_ID_USERS_FAILED = "get/get_id_users/failed";
