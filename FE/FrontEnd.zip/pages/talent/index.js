import LandingPage from "../component/layout/LandingPage";

export default function talent() {
    return (
        <div>
            <LandingPage>
                Talent
            </LandingPage>
        </div>
    )
}
