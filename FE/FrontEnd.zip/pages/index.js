import LandingPage from "./component/layout/LandingPage";

export default function Home() {
  return (
    <div>
      <LandingPage>
      <>Home</>
      </LandingPage>
    </div>
  )
}
